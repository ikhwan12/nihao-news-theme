=== Plugin Name ===
Contributors: semvironment
Donate link: http://www.semvironment.com
Tags: keyword research bloggerizer
Requires at least: 2.0.2
Tested up to: 2.6
Stable tag: 1.0

Allows you to perform keyword research from your edit/post pages while writing. Opens a new window when you click on a research link.

== Description ==

Allows you to perform keyword research from your edit/post pages while writing. Opens a new window when you click on a research link.

== Installation ==

1. Upload the file `post_keyword_research.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Simply write a post and note the research links below your submenu and to the right below the 'save'/'publish' button.

== Frequently Asked Questions ==

None yet. :)